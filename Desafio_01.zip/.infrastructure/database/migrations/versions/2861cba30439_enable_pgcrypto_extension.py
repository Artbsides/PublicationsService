"""enable pgcrypto extension

Revision ID: 2861cba30439
Revises: 
Create Date: 2026-02-27 13:32:29.134090

"""
import sqlalchemy as sa

from typing import Union, Sequence
from alembic import op


# revision identifiers, used by Alembic.
revision: str = '2861cba30439'
down_revision: Union[str, Sequence[str], None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.execute('CREATE EXTENSION IF NOT EXISTS pgcrypto;')


def downgrade() -> None:
    """Downgrade schema."""
    op.execute('DROP EXTENSION IF EXISTS pgcrypto;')
